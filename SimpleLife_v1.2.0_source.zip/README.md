# Simple Life — Android app (v1.2.0)

Simple Life is a free, fully offline everyday-tools app for Android, in **Pashto (پښتو), Persian/Dari (فارسی) and English**.
Made by Abdul Samim Niazai, Alingar District, Laghman, Afghanistan.

## What it does
- **Tasks** – add, edit, complete/uncomplete, delete; separate *Active* and *Completed* lists.
- **Notes** – create, edit, delete (with confirmation), search, copy, share, warning before losing unsaved changes.
- **Expenses** – title, amount, category, date; edit/delete; totals for *this month* / *all time*; breakdown by category; default currency AFN.
- **Calculator** – + − × ÷ %, decimals, error messages (e.g. divide by zero). Own parser, no `eval`.
- **Unit converter** – length, weight, temperature, area, volume.
- **Settings** – language (ps / fa / en), theme (light / dark / system), backup (share or copy), restore, delete all data.
- **About the creator** – photo, greeting, location, education, purpose, contact (email / dialer / copy).
- Right-to-left layout for Pashto and Persian, left-to-right for English. Language and theme are remembered.

## Offline and privacy
- No internet permission (the manifest declares **no permissions at all**), no ads, no analytics, no tracking.
- The WebView is also set to block network loads and to refuse navigating anywhere except the bundled pages.
- Data is stored on the phone (Android SharedPreferences). It is **not encrypted**, and is lost if you uninstall the app or clear its data. Use *Settings → Share/Copy backup* now and then.
- Email and phone buttons only open your mail app / dialer. Nothing is sent or called automatically.

## Architecture
A WebView app: the UI is local HTML/CSS/JS in `assets/`, and a small native bridge (`MainActivity.java`) provides storage, copy/share, email/dial and theme/system-bar handling.
Kept as WebView on purpose: it lets one codebase give full RTL text shaping for Pashto/Persian, and builds with **zero third-party dependencies**.

```
app/src/main/
  AndroidManifest.xml
  java/com/samim/simplelife/MainActivity.java   native bridge
  assets/index.html                             entry page (strict Content-Security-Policy)
  assets/css/app.css                            light + dark theme variables, RTL-safe layout
  assets/js/i18n.js                             ALL translations (ps / fa / en)
  assets/js/app.js                              app logic
  assets/profile.png                            creator photo
  res/                                          icons (adaptive + legacy PNG), splash, themes
tests/ui.test.js                                automated browser test (developer only)
.github/workflows/build-apk.yml                 cloud build -> downloadable APK
legacy/SimpleLife-Offline-Demo.html             the old standalone demo page (kept for reference)
```
Old data from v1.1 (tasks, notes, expenses, dark-mode flag) is migrated automatically.

## Build the APK from an Android phone (GitHub Actions)
1. Open github.com in your phone browser (or the GitHub app), sign in, and create a **new repository** (e.g. `simple-life`).
2. Upload the **contents** of this project (not the outer ZIP file) so that `app/`, `build.gradle`, `settings.gradle` and the **`.github`** folder are at the top level of the repository. Tip: on the GitHub website choose *Add file → Upload files*; if your file manager cannot upload a folder starting with a dot, create the workflow file by hand: *Add file → Create new file*, name it `.github/workflows/build-apk.yml`, and paste the contents of that file.
3. Open the **Actions** tab → **Build Android APK** → **Run workflow** (green button). If GitHub asks, tap *"I understand my workflows, go ahead and enable them"*.
4. Wait ~5–10 minutes. Open the finished run (green tick) → scroll to **Artifacts** → download **simple-life-debug-apk** (a ZIP).
5. Extract the ZIP on your phone; install `app-debug.apk` (allow *Install unknown apps* for your browser/file manager when Android asks).

If the run shows a red cross, open it and read the failing step; the error text is shown there.

## Build on a computer (optional)
Android Studio (Koala or newer) → *Open* this folder → *Build → Build APK(s)*. Or with Gradle 8.7 + JDK 17 + Android SDK 35: `gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.
Requirements: JDK 17, Android SDK Platform 35, Gradle 8.7 (Android Gradle Plugin 8.6.1), minSdk 23 (Android 6.0), targetSdk 35.

## The APK is a DEBUG build
It is signed with Android's automatic debug key, so it installs fine, but it is not a Play-Store release. A release build needs your own signing key.

## Testing status (honest report)
**Passed (automated, 192 checks, `tests/ui.test.js`, headless desktop Chromium with a mock of the Android bridge):**
translation completeness; language switching and persistence; RTL/LTR; light/dark theme and persistence; tasks, notes, expenses, calculator, converter, about/contact actions, backup/restore/clear; invalid-input handling; unsaved-changes guard; back-button logic; migration of v1.1 data; zero network requests; no JS errors; no horizontal overflow at 320/360/412/768 px in all three languages.

**NOT verified (could not be done in the authoring environment, which has no Android SDK, no Gradle and no internet):**
- The Android Gradle build itself and the actual APK. `MainActivity.java` was only checked for syntax, never compiled. **If the first cloud build fails, send the error text and it will be fixed.**
- Running on a real phone/emulator: real WebView rendering, fonts for Pashto on your phone, status/navigation-bar handling on Android 15 edge-to-edge, keyboard behaviour, share sheet, email/dialer intents, behaviour after force-stop.
- Android 6–8 devices with an outdated system WebView may lay out some elements differently.

## Known limitations
- Dates are Gregorian (no Hijri-Shamsi calendar yet). Numbers use Latin digits (Persian/Arabic digits are accepted as input).
- No custom Pashto font is bundled; the phone's system Arabic-script font is used.
- Data is local and unencrypted; there is no cloud sync. Backup/restore is manual (copy/paste text).
- Single currency (AFN).

## لنډه پښتو لارښود
دا اپ بشپړ افلاین دی او هېڅ اجازه نه غواړي. د APK لپاره: پروژه GitHub ته پورته کړئ → **Actions → Build Android APK → Run workflow** → وروسته له بریا **simple-life-debug-apk** ښکته کړئ، له ZIP څخه `app-debug.apk` را وباسئ او نصب یې کړئ. یادونه: APK لا په دې چاپېریال کې نه دی جوړ شوی؛ لومړی GitHub build باید وازمایل شي، که ناکام شو د تېروتنې متن راولېږئ.
