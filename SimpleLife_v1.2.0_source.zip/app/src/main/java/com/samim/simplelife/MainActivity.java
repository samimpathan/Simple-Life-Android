package com.samim.simplelife;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.util.regex.Pattern;

/**
 * Simple Life: a fully offline WebView app. All UI lives in assets/ (no remote content).
 * The app declares no permissions, so it cannot access the network at all.
 */
public class MainActivity extends Activity {
    private static final String ASSET_URL = "file:///android_asset/index.html";
    private static final String PREFS = "simple_life_data";
    private static final int LIGHT_BG = 0xFFF5F7F6;
    private static final int DARK_BG = 0xFF0F1513;
    private static final Pattern KEY = Pattern.compile("^sl_[a-z_]{1,32}$");
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE = Pattern.compile("^\\+?[0-9]{3,15}$");

    private FrameLayout root;
    private WebView web;
    private SharedPreferences prefs;
    private boolean pageReady = false;
    private int insetTopPx = 0, insetBottomPx = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        root = new FrameLayout(this);
        root.setBackgroundColor(LIGHT_BG);
        web = new WebView(this);
        web.setBackgroundColor(LIGHT_BG);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // fallback storage only; real data goes to SharedPreferences
        s.setAllowFileAccess(false);           // android_asset URLs still work
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setBlockNetworkLoads(true);          // belt and braces: nothing is ever fetched from the internet
        s.setSupportMultipleWindows(false);
        s.setGeolocationEnabled(false);
        s.setSaveFormData(false);
        s.setTextZoom(100);
        WebView.setWebContentsDebuggingEnabled(false);

        web.addJavascriptInterface(new Bridge(), "SimpleLifeAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // never navigate away from the bundled app
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { pageReady = false; }
            @Override public void onPageFinished(WebView view, String url) { pageReady = true; pushInsets(); }
        });

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, r, top, bottom, ime = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                ime = insets.getInsets(WindowInsets.Type.ime()).bottom;
                l = bars.left; r = bars.right; top = bars.top; bottom = bars.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); r = insets.getSystemWindowInsetRight();
                top = insets.getSystemWindowInsetTop(); bottom = insets.getSystemWindowInsetBottom();
            }
            boolean imeVisible = ime > bottom;
            root.setPadding(l, 0, r, imeVisible ? ime : 0);   // lift the page above the keyboard
            insetTopPx = top;
            insetBottomPx = imeVisible ? 0 : bottom;
            pushInsets();
            return insets;
        });

        web.loadUrl(ASSET_URL);
    }

    private void pushInsets() {
        if (!pageReady || web == null) return;
        float d = getResources().getDisplayMetrics().density;
        final String js = "window.setInsets&&window.setInsets(" + Math.round(insetTopPx / d) + "," + Math.round(insetBottomPx / d) + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private void callback(final String name, final boolean ok) {
        final String js = "window.onNative&&window.onNative('" + name + "'," + ok + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void applyTheme(boolean dark) {
        int bg = dark ? DARK_BG : LIGHT_BG;
        root.setBackgroundColor(bg);
        web.setBackgroundColor(bg);
        if (Build.VERSION.SDK_INT < 35) {
            getWindow().setStatusBarColor(dark ? 0xFF10241C : 0xFF0F4A37);
            getWindow().setNavigationBarColor(bg);
        }
        // Status bar sits on the dark-green header in both themes (light icons); navigation bar follows the page.
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
                c.setSystemBarsAppearance(dark ? 0 : WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        } else if (Build.VERSION.SDK_INT >= 26) {
            View decor = getWindow().getDecorView();
            int f = decor.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            f = dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            decor.setSystemUiVisibility(f);
        }
    }

    /** Methods below are callable from the bundled JavaScript only (no remote page can be loaded). */
    private class Bridge {
        @JavascriptInterface public String getItem(String key) {
            if (key == null || !KEY.matcher(key).matches()) return null;
            return prefs.getString(key, null);
        }
        @JavascriptInterface public boolean setItem(String key, String value) {
            if (key == null || value == null || !KEY.matcher(key).matches() || value.length() > 4_000_000) return false;
            return prefs.edit().putString(key, value).commit();   // synchronous, survives process death
        }
        @JavascriptInterface public void removeItem(String key) {
            if (key != null && KEY.matcher(key).matches()) prefs.edit().remove(key).commit();
        }
        @JavascriptInterface public void setTheme(final boolean dark) { runOnUiThread(() -> applyTheme(dark)); }

        @JavascriptInterface public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && text != null) cm.setPrimaryClip(ClipData.newPlainText("Simple Life", text));
            });
        }
        @JavascriptInterface public void share(final String title, final String text) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Simple Life" : title);
                    i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    startActivity(Intent.createChooser(i, title == null ? "Simple Life" : title));
                } catch (ActivityNotFoundException e) { callback("share", false); }
            });
        }
        @JavascriptInterface public void email(final String address, final String subject) {
            if (address == null || !EMAIL.matcher(address).matches()) { callback("email", false); return; }
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + address));
                    i.putExtra(Intent.EXTRA_SUBJECT, subject == null ? "" : subject);
                    startActivity(i);              // opens the user's mail app; nothing is sent automatically
                } catch (ActivityNotFoundException e) { callback("email", false); }
            });
        }
        @JavascriptInterface public void dial(final String number) {
            if (number == null || !PHONE.matcher(number).matches()) { callback("dial", false); return; }
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));   // dialer only, never auto-calls
                } catch (ActivityNotFoundException e) { callback("dial", false); }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (!pageReady) { finish(); return; }
        web.evaluateJavascript("window.handleBack?window.handleBack():false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    @Override
    protected void onDestroy() {
        if (web != null) {
            root.removeView(web);
            web.removeJavascriptInterface("SimpleLifeAndroid");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
