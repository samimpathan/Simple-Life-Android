/* Simple Life - application logic. No network access, no eval. */
(function () {
  'use strict';
  var VERSION = '1.2.0';
  var bridge = window.SimpleLifeAndroid || null;
  var K = { tasks: 'sl_tasks', notes: 'sl_notes', expenses: 'sl_expenses', lang: 'sl_lang', theme: 'sl_theme', legacyDark: 'sl_dark' };
  var LANGS = { ps: 'پښتو', fa: 'فارسی', en: 'English' };
  var CATS = ['food', 'transport', 'study', 'bills', 'health', 'shopping', 'general'];
  var GREETING = 'وَعَلَيْكُم السَّلَام وَرَحْمَةُ اَللهِ وَبَرَكاتُهُ‎';
  var EMAIL = 'samimpatan8@gmail.com';
  var PHONES = [['Etisalat', '0789591758'], ['AWCC / Atoma', '0767803096'], ['Salaam', '0747320602']];

  /* ---------- storage (native SharedPreferences via bridge, localStorage fallback) ---------- */
  var Store = {
    get: function (k) {
      try {
        if (bridge && bridge.getItem) { var v = bridge.getItem(k); if (v !== null && v !== undefined) return v; }
        return window.localStorage.getItem(k);
      } catch (e) { return null; }
    },
    set: function (k, v) {
      try {
        if (bridge && bridge.setItem) return bridge.setItem(k, v) === true;
        window.localStorage.setItem(k, v); return true;
      } catch (e) { return false; }
    },
    del: function (k) {
      try { if (bridge && bridge.removeItem) bridge.removeItem(k); } catch (e) {}
      try { window.localStorage.removeItem(k); } catch (e) {}
    }
  };

  /* ---------- helpers ---------- */
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function toLatinDigits(s) {
    return String(s).replace(/[\u06f0-\u06f9]/g, function (c) { return c.charCodeAt(0) - 0x06f0; })
      .replace(/[\u0660-\u0669]/g, function (c) { return c.charCodeAt(0) - 0x0660; });
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function todayISO() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function validDate(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    var p = s.split('-'), d = new Date(+p[0], +p[1] - 1, +p[2]);
    return d.getFullYear() === +p[0] && d.getMonth() === +p[1] - 1 && d.getDate() === +p[2];
  }
  function fmtNum(n, frac) { return Number(n).toLocaleString('en-US', { maximumFractionDigits: frac == null ? 2 : frac }); }
  function money(cents) { return '<span class="num">' + fmtNum(cents / 100, 2) + '</span> ' + esc(t('currency')); }
  function parseAmount(s) {
    s = toLatinDigits(s).replace(/[\s\u00a0\u066c,]/g, '').replace(/\u066b/g, '.');
    if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) return NaN;
    var n = parseFloat(s);
    return n > 0 ? n : NaN;
  }
  function cents(a) { return Math.round(Number(a) * 100); }

  /* ---------- state ---------- */
  var S = { lang: 'ps', theme: 'system', page: 'home', stack: [], taskTab: 'active', expRange: 'month', noteQ: '', calc: null, conv: { cat: 'length', from: 'm', to: 'km', val: '1' } };
  var tasks = [], notes = [], expenses = [];

  function t(k) { var d = window.I18N[S.lang]; return (d && d[k]) || window.I18N.en[k] || k; }

  function loadArr(k) {
    var raw = Store.get(k); if (!raw) return [];
    try { var o = JSON.parse(raw); return Array.isArray(o) ? o : []; } catch (e) { return []; }
  }
  function cleanTask(x) {
    if (!x || typeof x !== 'object') return null;
    var title = String(x.title == null ? '' : x.title).trim().slice(0, 180); if (!title) return null;
    return { id: String(x.id || uid()), title: title, done: x.done === true, created: Number(x.created) || Date.now() };
  }
  function cleanNote(x) {
    if (!x || typeof x !== 'object') return null;
    var text = String(x.text == null ? '' : x.text).slice(0, 5000), title = String(x.title == null ? '' : x.title).trim().slice(0, 100);
    if (!text.trim() && !title) return null;
    var upd = Number(x.updated) || Date.parse(x.date) || Date.now();
    return { id: String(x.id || uid()), title: title, text: text, updated: upd };
  }
  function cleanExp(x) {
    if (!x || typeof x !== 'object') return null;
    var title = String(x.title == null ? '' : x.title).trim().slice(0, 100), a = Number(x.amount);
    if (!title || !isFinite(a) || a <= 0 || a > 999999999) return null;
    var cat = String(x.category || 'general').toLowerCase(); if (CATS.indexOf(cat) < 0) cat = 'general';
    var date = validDate(String(x.date)) ? String(x.date) : todayISO();
    return { id: String(x.id || uid()), title: title, amount: Math.round(a * 100) / 100, category: cat, date: date };
  }
  function clean(arr, fn) { var out = []; for (var i = 0; i < arr.length; i++) { var c = fn(arr[i]); if (c) out.push(c); } return out; }
  function persist(key, arr) { var ok = Store.set(key, JSON.stringify(arr)); if (!ok) toast(t('err_storage'), true); return ok; }

  /* ---------- toast ---------- */
  var toastTimer = null;
  function toast(msg, bad) {
    var el = $('#toast'); if (!el) return;
    el.textContent = msg; el.className = 'show' + (bad ? ' bad' : '');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.className = ''; }, 2200);
  }

  /* ---------- icons ---------- */
  var IC = {
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
    tasks: '<circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/>',
    notes: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
    wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2z"/><circle cx="16" cy="14.5" r="1"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
    conv: '<path d="M17 3l4 4-4 4"/><path d="M3 11V9a2 2 0 0 1 2-2h16"/><path d="M7 21l-4-4 4-4"/><path d="M21 13v2a2 2 0 0 1-2 2H3"/>',
    settings: '<path d="M4 6h8M16 6h4M4 12h3M11 12h9M4 18h10M18 18h2"/><circle cx="14" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="16" cy="18" r="2"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v5M14 11v5"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    phone: '<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    chev: '<path d="M9 6l6 6-6 6"/>',
    swap: '<path d="M7 4v16M3 16l4 4 4-4M17 20V4M13 8l4-4 4 4"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    bksp: '<path d="M21 5H9l-6 7 6 7h12z"/><path d="M13 9l4 6M17 9l-4 6"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>'
  };
  function ic(n, cls) { return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (IC[n] || '') + '</svg>'; }
  function iconBtn(act, icon, label, extra, cls) {
    return '<button type="button" class="icon-btn sm' + (cls ? ' ' + cls : '') + '" data-act="' + act + '" ' + (extra || '') + ' aria-label="' + esc(label) + '" title="' + esc(label) + '">' + ic(icon) + '</button>';
  }
  function emptyState(icon, msg, btn) {
    return '<div class="empty"><div class="ic-wrap">' + ic(icon) + '</div><p>' + esc(msg) + '</p>' + (btn || '') + '</div>';
  }

  /* ---------- theme / language ---------- */
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function effectiveTheme() { return S.theme === 'system' ? (mq && mq.matches ? 'dark' : 'light') : S.theme; }
  function applyTheme() {
    var eff = effectiveTheme();
    document.documentElement.setAttribute('data-theme', eff);
    try { if (bridge && bridge.setTheme) bridge.setTheme(eff === 'dark'); } catch (e) {}
  }
  function applyLang() {
    document.documentElement.lang = S.lang;
    document.documentElement.dir = S.lang === 'en' ? 'ltr' : 'rtl';
    document.title = 'Simple Life';
  }
  function setTheme(v) { S.theme = v; Store.set(K.theme, v); applyTheme(); renderAll(); }
  function setLang(v) { if (!LANGS[v]) return; S.lang = v; Store.set(K.lang, v); applyLang(); renderAll(); }
  window.setInsets = function (top, bottom) {
    var r = document.documentElement.style;
    r.setProperty('--sat', (Number(top) || 0) + 'px'); r.setProperty('--sab', (Number(bottom) || 0) + 'px');
  };

  /* ---------- modals ---------- */
  var modals = [];
  function topModal() { return modals[modals.length - 1]; }
  function findModal(el) { var s = el.closest('.scrim'); for (var i = 0; i < modals.length; i++) if (modals[i].el === s) return modals[i]; return null; }
  function destroyModal(m) { var i = modals.indexOf(m); if (i >= 0) modals.splice(i, 1); if (m.el.parentNode) m.el.parentNode.removeChild(m.el); }
  function requestClose(m) {
    if (m.o.isDirty && m.o.isDirty()) {
      confirmBox({ title: t('discard_title'), msg: t('discard_msg'), okLabel: t('discard_ok'), cancelLabel: t('keep_editing'), danger: true, onOk: function () { destroyModal(m); } });
      return;
    }
    destroyModal(m);
  }
  function openSheet(o) {
    var wrap = document.createElement('div');
    wrap.className = 'scrim' + (o.dialog ? ' dlg' : '');
    var head = '<div class="sheet-head"><h2>' + esc(o.title) + '</h2>' + (o.dialog ? '' : iconBtn('modal-close', 'x', t('close'))) + '</div>';
    var acts = '<div class="sheet-actions"><button type="button" class="btn sec" data-act="modal-cancel">' + esc(o.cancelLabel || t('cancel')) + '</button>' +
      '<button type="submit" class="btn' + (o.danger ? ' dng' : '') + '">' + esc(o.okLabel || t('save')) + '</button></div>';
    wrap.innerHTML = '<div class="sheet' + (o.full ? ' full' : '') + '" role="dialog" aria-modal="true" aria-label="' + esc(o.title) + '">' + head +
      '<form novalidate><div class="sheet-body">' + o.body + '<div class="err" role="alert"></div></div>' + acts + '</form></div>';
    document.body.appendChild(wrap);
    var m = { el: wrap, o: o }; modals.push(m);
    wrap.addEventListener('mousedown', function (e) { if (e.target === wrap) requestClose(m); });
    if (o.onMount) o.onMount(wrap);
    if (!o.dialog) { var f = wrap.querySelector('input,textarea,select'); if (f) setTimeout(function () { try { f.focus(); } catch (e) {} }, 60); }
    return m;
  }
  function confirmBox(o) {
    openSheet({ dialog: true, title: o.title || t('confirm_title'), body: '<p>' + esc(o.msg) + '</p>', okLabel: o.okLabel || t('delete'), cancelLabel: o.cancelLabel, danger: o.danger !== false, onSubmit: function () { o.onOk(); return true; } });
  }
  function showErr(form, msg) { var e = form.querySelector('.err'); if (e) e.textContent = msg || ''; }

  /* ---------- navigation ---------- */
  var MAIN_PAGES = ['home', 'tasks', 'notes', 'expenses', 'more'];
  function go(page, push) {
    if (push) S.stack.push(S.page); else S.stack = [];
    S.page = page; renderAll(); window.scrollTo(0, 0);
  }
  function back() {
    if (S.stack.length) { S.page = S.stack.pop(); renderAll(); window.scrollTo(0, 0); return true; }
    if (S.page === 'more' || S.page === 'tasks' || S.page === 'notes' || S.page === 'expenses') { S.page = 'home'; renderAll(); return true; }
    if (['calc', 'conv', 'settings', 'about'].indexOf(S.page) >= 0) { S.page = 'more'; renderAll(); return true; }
    return false;
  }
  window.handleBack = function () {
    var m = topModal(); if (m) { requestClose(m); return true; }
    return back();
  };
  function pageTitle() {
    var p = S.page;
    return { home: 'Simple Life', tasks: t('tasks_title'), notes: t('notes_title'), expenses: t('exp_title'), more: t('nav_more'), calc: t('calc_title'), conv: t('conv_title'), settings: t('settings_title'), about: t('about_title') }[p];
  }

  /* ---------- shell ---------- */
  function renderAll() {
    var app = $('#app');
    try {
      var isHome = S.page === 'home', eff = effectiveTheme();
      var showBack = MAIN_PAGES.indexOf(S.page) < 0 || S.stack.length > 0;
      var nav = [['home', 'home', 'nav_home'], ['tasks', 'tasks', 'nav_tasks'], ['notes', 'notes', 'nav_notes'], ['expenses', 'wallet', 'nav_expenses'], ['more', 'grid', 'nav_more']];
      var navPage = MAIN_PAGES.indexOf(S.page) >= 0 ? S.page : (S.stack.length ? S.stack[0] : 'more');
      if (MAIN_PAGES.indexOf(navPage) < 0) navPage = 'more';
      app.innerHTML =
        '<div class="shell"><header class="top"><div class="top-row">' +
        (showBack ? '<button type="button" class="icon-btn" data-act="back" aria-label="' + esc(t('back')) + '">' + ic('back', 'flip') + '</button>' : '') +
        '<div class="top-title">' + esc(pageTitle()) + '</div>' +
        '<button type="button" class="icon-btn" data-act="theme-toggle" aria-label="' + esc(t('theme_toggle')) + '">' + ic(eff === 'dark' ? 'sun' : 'moon') + '</button>' +
        '<button type="button" class="icon-btn lang-btn" data-act="lang-open" aria-label="' + esc(t('language')) + '">' + S.lang.toUpperCase() + '</button></div>' +
        (isHome ? '<div class="hero"><h1>' + esc(t('welcome')) + '</h1><p>' + esc(t('welcome_sub')) + '</p></div>' : '') +
        '</header><main id="main"></main></div>' +
        '<nav class="nav" aria-label="Main"><div class="nav-in">' + nav.map(function (n) {
          return '<button type="button" data-act="nav" data-v="' + n[0] + '"' + (n[0] === navPage ? ' aria-current="page"' : '') + '>' + ic(n[1]) + '<span>' + esc(t(n[2])) + '</span></button>';
        }).join('') + '</div></nav>';
      renderMain();
    } catch (e) {
      app.innerHTML = '<div class="card" style="margin:20px"><p>' + esc(t('err_generic')) + '</p><button class="btn" data-act="reload">' + esc(t('reload')) + '</button></div>';
      if (window.console) console.error(e);
    }
  }
  function renderMain() {
    var m = $('#main'); if (!m) return;
    var fn = { home: pHome, tasks: pTasks, notes: pNotes, expenses: pExpenses, more: pMore, calc: pCalc, conv: pConv, settings: pSettings, about: pAbout }[S.page] || pHome;
    m.innerHTML = fn();
    var after = { calc: calcRefresh, conv: convRefresh }[S.page]; if (after) after();
  }

  /* ---------- Home / More ---------- */
  function monthKey() { return todayISO().slice(0, 7); }
  function monthSum() { var s = 0; expenses.forEach(function (e) { if (e.date.slice(0, 7) === monthKey()) s += cents(e.amount); }); return s; }
  function toolBtn(page, icon, label) { return '<button type="button" class="tool" data-act="open" data-v="' + page + '"><span class="ic-wrap">' + ic(icon) + '</span><span class="t">' + esc(label) + '</span></button>'; }
  function pHome() {
    var active = tasks.filter(function (x) { return !x.done; }).length;
    return '<div class="grid3">' +
      '<button type="button" class="stat" data-act="nav" data-v="tasks"><b>' + active + '</b><span>' + esc(t('stat_tasks')) + '</span></button>' +
      '<button type="button" class="stat" data-act="nav" data-v="expenses"><b>' + money(monthSum()) + '</b><span>' + esc(t('stat_month')) + '</span></button>' +
      '<button type="button" class="stat" data-act="nav" data-v="notes"><b>' + notes.length + '</b><span>' + esc(t('stat_notes')) + '</span></button></div>' +
      '<div class="sec-title">' + esc(t('tools')) + '</div><div class="grid2">' +
      toolBtn('tasks', 'tasks', t('tasks_title')) + toolBtn('notes', 'notes', t('notes_title')) + toolBtn('expenses', 'wallet', t('exp_title')) +
      toolBtn('calc', 'calc', t('calc_title')) + toolBtn('conv', 'conv', t('conv_title')) + toolBtn('about', 'user', t('about_title')) + '</div>' +
      '<div class="card" style="margin-top:16px"><div class="row"><span class="row-ic">' + ic('lock') + '</span><div class="grow"><b>' + esc(t('privacy_short')) + '</b><div class="muted">' + esc(t('offline_note')) + '</div></div></div></div>';
  }
  function linkRow(page, icon, label) {
    return '<button type="button" class="list-link" data-act="open" data-v="' + page + '"><span class="row-ic">' + ic(icon) + '</span><span class="t">' + esc(label) + '</span>' + ic('chev', 'flip') + '</button>';
  }
  function pMore() {
    return linkRow('calc', 'calc', t('calc_title')) + linkRow('conv', 'conv', t('conv_title')) + linkRow('settings', 'settings', t('settings_title')) + linkRow('about', 'user', t('about_title'));
  }

  /* ---------- Tasks ---------- */
  function taskItemsHTML() {
    var done = S.taskTab === 'done';
    var list = tasks.filter(function (x) { return x.done === done; });
    if (!list.length) return emptyState('tasks', done ? t('task_empty_done') : t('task_empty_active'));
    return list.map(function (x) {
      return '<div class="item' + (x.done ? ' done' : '') + '"><button type="button" class="chk" role="checkbox" aria-checked="' + x.done + '" data-act="task-toggle" data-id="' + x.id + '" aria-label="' + esc(x.done ? t('task_mark_undone') : t('task_mark_done')) + '">' + ic('check') + '</button>' +
        '<div class="main"><div class="ttl" dir="auto">' + esc(x.title) + '</div></div><div class="acts">' +
        iconBtn('task-edit', 'edit', t('edit'), 'data-id="' + x.id + '"') + iconBtn('task-del', 'trash', t('delete'), 'data-id="' + x.id + '"', 'danger') + '</div></div>';
    }).join('');
  }
  function pTasks() {
    var na = tasks.filter(function (x) { return !x.done; }).length, nd = tasks.length - na;
    return '<form class="card" id="taskForm" novalidate><label class="lbl" for="taskIn" style="margin-top:0">' + esc(t('task_add_label')) + '</label><div class="row">' +
      '<input id="taskIn" class="field grow" dir="auto" maxlength="400" placeholder="' + esc(t('task_ph')) + '" autocomplete="off"><button class="btn" type="submit" aria-label="' + esc(t('add')) + '">' + ic('plus') + '</button></div><div class="err" role="alert" id="taskErr"></div></form>' +
      '<div class="seg" role="group"><button type="button" data-act="task-tab" data-v="active" aria-pressed="' + (S.taskTab === 'active') + '">' + esc(t('task_tab_active')) + ' (' + na + ')</button>' +
      '<button type="button" data-act="task-tab" data-v="done" aria-pressed="' + (S.taskTab === 'done') + '">' + esc(t('task_tab_done')) + ' (' + nd + ')</button></div>' +
      '<div class="card" id="taskList">' + taskItemsHTML() + '</div>';
  }
  function validateTask(s) { s = s.trim(); if (!s) return t('task_err_empty'); if (s.length > 180) return t('task_err_long'); return ''; }
  function taskEdit(id) {
    var x = tasks.filter(function (a) { return a.id === id; })[0]; if (!x) return;
    openSheet({
      title: t('task_edit'), body: '<input class="field" name="v" dir="auto" maxlength="400" value="' + esc(x.title) + '">',
      isDirty: function () { return false; },
      onSubmit: function (form) {
        var v = form.v.value, e = validateTask(v); if (e) { showErr(form, e); return false; }
        x.title = v.trim(); if (!persist(K.tasks, tasks)) return false; toast(t('toast_saved')); renderMain(); return true;
      }
    });
  }

  /* ---------- Notes ---------- */
  function noteTitle(n) { return n.title || (n.text.trim().split('\n')[0].slice(0, 60)) || t('note_untitled'); }
  function noteDate(n) { var d = new Date(n.updated); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function noteListHTML() {
    var q = S.noteQ.trim().toLowerCase();
    var list = notes.filter(function (n) { return !q || (n.title + '\n' + n.text).toLowerCase().indexOf(q) >= 0; }).sort(function (a, b) { return b.updated - a.updated; });
    if (!list.length) return emptyState('notes', q ? t('note_nomatch') : t('note_empty'));
    return list.map(function (n) {
      return '<div class="item"><div class="main" data-act="note-edit" data-id="' + n.id + '" role="button" tabindex="0"><div class="ttl" dir="auto">' + esc(noteTitle(n)) + '</div>' +
        '<div class="note-prev" dir="auto">' + esc(n.text) + '</div><div class="sub"><span class="num">' + esc(noteDate(n)) + '</span></div></div><div class="acts" style="flex-direction:column">' +
        '<div class="row">' + iconBtn('note-copy', 'copy', t('copy'), 'data-id="' + n.id + '"') + iconBtn('note-share', 'share', t('share'), 'data-id="' + n.id + '"') + '</div>' +
        '<div class="row">' + iconBtn('note-edit', 'edit', t('edit'), 'data-id="' + n.id + '"') + iconBtn('note-del', 'trash', t('delete'), 'data-id="' + n.id + '"', 'danger') + '</div></div></div>';
    }).join('');
  }
  function pNotes() {
    return '<div class="row" style="margin-bottom:12px"><input id="noteQ" class="field grow" type="search" dir="auto" placeholder="' + esc(t('note_search')) + '" value="' + esc(S.noteQ) + '" aria-label="' + esc(t('note_search')) + '"></div>' +
      '<div class="card" id="noteList">' + noteListHTML() + '</div>' +
      '<button type="button" class="fab" data-act="note-new" aria-label="' + esc(t('note_new')) + '">' + ic('plus') + '</button>';
  }
  function noteText(n) { return (n.title ? n.title + '\n\n' : '') + n.text; }
  function noteEditor(id) {
    var n = id ? notes.filter(function (a) { return a.id === id; })[0] : null; if (id && !n) return;
    var t0 = n ? n.title : '', b0 = n ? n.text : '';
    openSheet({
      full: true, title: n ? t('note_edit') : t('note_new'),
      body: '<input class="field" name="title" dir="auto" maxlength="100" placeholder="' + esc(t('note_title_ph')) + '" value="' + esc(t0) + '" aria-label="' + esc(t('note_title_ph')) + '">' +
        '<div style="height:10px"></div><textarea class="field" name="body" dir="auto" maxlength="5000" placeholder="' + esc(t('note_body_ph')) + '" aria-label="' + esc(t('note_body_ph')) + '">' + esc(b0) + '</textarea>',
      isDirty: null,
      onSubmit: function (form) {
        var ti = form.title.value.trim(), bo = form.body.value;
        if (!ti && !bo.trim()) { showErr(form, t('note_err_empty')); return false; }
        if (n) { n.title = ti; n.text = bo; n.updated = Date.now(); } else notes.unshift({ id: uid(), title: ti, text: bo, updated: Date.now() });
        if (!persist(K.notes, notes)) return false;
        toast(t('toast_saved')); renderMain(); return true;
      }
    });
    var m = topModal(), form = m.el.querySelector('form');
    m.o.isDirty = function () { return form.title.value !== t0 || form.body.value !== b0; };
  }

  /* ---------- Expenses ---------- */
  function expInRange() {
    var list = expenses.slice();
    if (S.expRange === 'month') list = list.filter(function (e) { return e.date.slice(0, 7) === monthKey(); });
    return list.sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; });
  }
  function pExpenses() {
    var list = expInRange(), total = 0, by = {};
    list.forEach(function (e) { var c = cents(e.amount); total += c; by[e.category] = (by[e.category] || 0) + c; });
    var avg = list.length ? Math.round(total / list.length) : 0;
    var catRows = Object.keys(by).sort(function (a, b) { return by[b] - by[a]; }).map(function (c) {
      return '<div class="cat-row"><div class="row"><span>' + esc(t('cat_' + c)) + '</span><b>' + money(by[c]) + '</b></div><div class="bar"><i style="width:' + Math.max(3, Math.round(by[c] * 100 / total)) + '%"></i></div></div>';
    }).join('');
    var items = list.length ? list.map(function (e) {
      return '<div class="item"><div class="main"><div class="ttl" dir="auto">' + esc(e.title) + '</div><div class="sub">' + esc(t('cat_' + e.category)) + ' · <span class="num">' + esc(e.date) + '</span></div></div>' +
        '<b>' + money(cents(e.amount)) + '</b><div class="acts">' + iconBtn('exp-edit', 'edit', t('edit'), 'data-id="' + e.id + '"') + iconBtn('exp-del', 'trash', t('delete'), 'data-id="' + e.id + '"', 'danger') + '</div></div>';
    }).join('') : emptyState('wallet', t('exp_empty'));
    return '<div class="seg" role="group"><button type="button" data-act="exp-range" data-v="month" aria-pressed="' + (S.expRange === 'month') + '">' + esc(t('exp_range_month')) + '</button>' +
      '<button type="button" data-act="exp-range" data-v="all" aria-pressed="' + (S.expRange === 'all') + '">' + esc(t('exp_range_all')) + '</button></div>' +
      '<div class="card"><div class="muted">' + esc(t('exp_total')) + '</div><div class="big">' + money(total) + '</div>' +
      '<div class="row" style="margin-top:8px"><span class="pill">' + esc(t('exp_count')) + ': <span class="num">' + list.length + '</span></span><span class="pill">' + esc(t('exp_avg')) + ': ' + money(avg) + '</span></div></div>' +
      (catRows ? '<div class="card"><h2>' + esc(t('exp_by_cat')) + '</h2>' + catRows + '</div>' : '') +
      '<div class="card">' + items + '</div>' +
      '<button type="button" class="fab" data-act="exp-new" aria-label="' + esc(t('exp_add')) + '">' + ic('plus') + '</button>';
  }
  function expForm(id) {
    var e = id ? expenses.filter(function (a) { return a.id === id; })[0] : null; if (id && !e) return;
    var opts = CATS.map(function (c) { return '<option value="' + c + '"' + ((e ? e.category : 'general') === c ? ' selected' : '') + '>' + esc(t('cat_' + c)) + '</option>'; }).join('');
    openSheet({
      title: e ? t('exp_edit') : t('exp_add'),
      body: '<label class="lbl">' + esc(t('exp_name')) + '</label><input class="field" name="title" dir="auto" maxlength="100" value="' + (e ? esc(e.title) : '') + '">' +
        '<label class="lbl">' + esc(t('exp_amount')) + ' (' + esc(t('currency')) + ')</label><input class="field ltr" name="amount" inputmode="decimal" autocomplete="off" placeholder="0.00" value="' + (e ? e.amount : '') + '">' +
        '<label class="lbl">' + esc(t('exp_category')) + '</label><select class="field" name="cat">' + opts + '</select>' +
        '<label class="lbl">' + esc(t('exp_date')) + '</label><input class="field ltr" name="date" type="date" value="' + (e ? e.date : todayISO()) + '">',
      onSubmit: function (form) {
        var title = form.title.value.trim(), a = parseAmount(form.amount.value), d = form.date.value;
        if (!title) { showErr(form, t('exp_err_title')); return false; }
        if (isNaN(a)) { showErr(form, t('exp_err_amount')); return false; }
        if (!validDate(d)) { showErr(form, t('exp_err_date')); return false; }
        var rec = { title: title, amount: a, category: form.cat.value, date: d };
        if (e) { e.title = rec.title; e.amount = rec.amount; e.category = rec.category; e.date = rec.date; } else { rec.id = uid(); expenses.unshift(rec); }
        if (!persist(K.expenses, expenses)) return false;
        toast(t('toast_saved')); renderMain(); return true;
      }
    });
  }

  /* ---------- Calculator (own parser, no eval) ---------- */
  function calcInit() { S.calc = { ex: '', res: '', err: '', fresh: false }; }
  var OPS = '+−×÷';
  function calcParse(src) {
    var i = 0;
    function peek() { return src.charAt(i); }
    function num() {
      var st = i; while (/[0-9.]/.test(peek())) i++;
      var s = src.slice(st, i); if (!s || s === '.' || (s.match(/\./g) || []).length > 1) throw new Error('syntax');
      var v = parseFloat(s); if (peek() === '%') { i++; v = v / 100; } return v;
    }
    function factor() { if (peek() === '−') { i++; return -factor(); } return num(); }
    function term() {
      var v = factor();
      while (peek() === '×' || peek() === '÷') {
        var o = src.charAt(i++), r = factor();
        if (o === '×') v *= r; else { if (r === 0) throw new Error('div0'); v /= r; }
      }
      return v;
    }
    function expr() { var v = term(); while (peek() === '+' || peek() === '−') { var o = src.charAt(i++), r = term(); v = o === '+' ? v + r : v - r; } return v; }
    var v = expr(); if (i !== src.length) throw new Error('syntax');
    if (!isFinite(v)) throw new Error('syntax');
    return v;
  }
  function calcFormat(v) {
    v = Number(v.toPrecision(12)); var s = String(Math.abs(v)); if (/e/i.test(s)) return (v < 0 ? '-' : '') + s;
    var p = s.split('.'); return (v < 0 ? '-' : '') + Number(p[0]).toLocaleString('en-US') + (p[1] ? '.' + p[1] : '');
  }
  function calcPress(k) {
    var c = S.calc; if (c.err) { c.err = ''; c.ex = ''; c.res = ''; c.fresh = false; }
    var last = c.ex.slice(-1), curNum = (c.ex.match(/[0-9.%]*$/) || [''])[0];
    if (/^[0-9]$/.test(k)) { if (c.fresh) { c.ex = ''; c.fresh = false; } if (c.ex.length < 40 && last !== '%') c.ex += k; }
    else if (k === '.') { if (c.fresh) { c.ex = ''; c.fresh = false; } if (curNum.indexOf('.') < 0 && last !== '%' && c.ex.length < 40) c.ex += (curNum === '' ? '0.' : '.'); }
    else if (OPS.indexOf(k) >= 0) {
      c.fresh = false;
      if (!c.ex) { if (k === '−') c.ex = '−'; }
      else if (c.ex === '−') { /* wait for number */ }
      else if (OPS.indexOf(last) >= 0) { if (k === '−' && last !== '−' && '×÷'.indexOf(last) >= 0) c.ex += k; else c.ex = c.ex.slice(0, -1) + k; }
      else if (c.ex.length < 40) c.ex += k;
    }
    else if (k === '%') { if (/[0-9]$/.test(c.ex)) c.ex += '%'; }
    else if (k === 'C') { c.ex = ''; c.res = ''; c.fresh = false; }
    else if (k === 'B') { c.ex = c.ex.slice(0, -1); c.fresh = false; }
    else if (k === '=') {
      if (!c.ex) return;
      var src = c.ex; if (OPS.indexOf(src.slice(-1)) >= 0) src = src.slice(0, -1);
      try { var v = calcParse(src); c.res = calcFormat(v); c.ex = String(Number(v.toPrecision(12))).replace('-', '−'); c.fresh = true; }
      catch (e) { c.err = e.message === 'div0' ? t('calc_div0') : t('calc_err'); c.res = ''; }
    }
    if (k !== '=') { try { var s2 = c.ex; if (OPS.indexOf(s2.slice(-1)) >= 0) s2 = s2.slice(0, -1); c.res = (s2 && s2 !== '−' && /[+−×÷]/.test(s2.slice(1))) ? calcFormat(calcParse(s2)) : ''; } catch (e) { c.res = ''; } }
    calcRefresh();
  }
  function pCalc() {
    if (!S.calc) calcInit();
    var keys = [['C', 'fn', 'C'], ['B', 'fn', ic('bksp')], ['%', 'op', '%'], ['÷', 'op', '÷'], ['7'], ['8'], ['9'], ['×', 'op', '×'], ['4'], ['5'], ['6'], ['−', 'op', '−'], ['1'], ['2'], ['3'], ['+', 'op', '+'], ['0'], ['.'], ['=', 'eq', '=']];
    var html = keys.map(function (k) {
      var lbl = k[2] || k[0], cls = k[1] ? ' ' + k[1] : '', style = k[0] === '0' ? ' style="grid-column:span 2"' : '', aria = k[0] === 'B' ? ' aria-label="' + esc(t('delete')) + '"' : '';
      return '<button type="button" class="key' + cls + '" data-act="calc" data-v="' + esc(k[0]) + '"' + style + aria + '>' + lbl + '</button>';
    }).join('');
    return '<div class="calc-disp" aria-live="polite"><div class="ex" id="cEx"></div><div class="rs" id="cRs"></div></div><div class="pad">' + html + '</div>';
  }
  function calcRefresh() {
    var c = S.calc, ex = $('#cEx'), rs = $('#cRs'); if (!ex || !rs) return;
    ex.textContent = c.ex; rs.className = 'rs' + (c.err ? ' bad' : '');
    rs.textContent = c.err || c.res || (c.ex ? '' : '0');
    if (c.fresh && !c.err) ex.textContent = '';
  }

  /* ---------- Unit converter ---------- */
  var UNITS = {
    length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, yd: 0.9144, ft: 0.3048, 'in': 0.0254 },
    weight: { kg: 1, g: 0.001, mg: 0.000001, lb: 0.45359237, oz: 0.028349523125, t: 1000 },
    area: { m2: 1, km2: 1000000, ha: 10000, ac: 4046.8564224, ft2: 0.09290304 },
    volume: { l: 1, ml: 0.001, gal: 3.785411784, qt: 0.946352946, floz: 0.0295735295625 },
    temp: { c: 1, f: 1, k: 1 }
  };
  var CONV_KEY = { length: 'ct_length', weight: 'ct_weight', area: 'ct_area', volume: 'ct_volume', temp: 'ct_temp' };
  function toC(v, u) { return u === 'c' ? v : u === 'f' ? (v - 32) * 5 / 9 : v - 273.15; }
  function fromC(v, u) { return u === 'c' ? v : u === 'f' ? v * 9 / 5 + 32 : v + 273.15; }
  function convert(cat, from, to, v) {
    if (cat === 'temp') return fromC(toC(v, from), to);
    return v * UNITS[cat][from] / UNITS[cat][to];
  }
  function parseNum(s) {
    s = toLatinDigits(s).replace(/[\s\u00a0\u066c,]/g, '').replace(/\u066b/g, '.');
    if (!/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return NaN; return parseFloat(s);
  }
  function unitOpts(cat, sel) { return Object.keys(UNITS[cat]).map(function (u) { return '<option value="' + u + '"' + (u === sel ? ' selected' : '') + '>' + esc(t('u_' + u)) + '</option>'; }).join(''); }
  function pConv() {
    var c = S.conv;
    var cats = Object.keys(CONV_KEY).map(function (k) { return '<option value="' + k + '"' + (k === c.cat ? ' selected' : '') + '>' + esc(t(CONV_KEY[k])) + '</option>'; }).join('');
    return '<div class="card"><label class="lbl" style="margin-top:0" for="cvCat">' + esc(t('conv_cat')) + '</label><select id="cvCat" class="field">' + cats + '</select>' +
      '<label class="lbl" for="cvVal">' + esc(t('conv_value')) + '</label><input id="cvVal" class="field ltr" inputmode="decimal" autocomplete="off" value="' + esc(c.val) + '">' +
      '<label class="lbl" for="cvFrom">' + esc(t('conv_from')) + '</label><select id="cvFrom" class="field">' + unitOpts(c.cat, c.from) + '</select>' +
      '<div class="row" style="justify-content:center;margin:10px 0"><button type="button" class="icon-btn" data-act="conv-swap" aria-label="' + esc(t('conv_swap')) + '">' + ic('swap') + '</button></div>' +
      '<label class="lbl" style="margin-top:0" for="cvTo">' + esc(t('conv_to')) + '</label><select id="cvTo" class="field">' + unitOpts(c.cat, c.to) + '</select></div>' +
      '<div class="card"><div class="muted">' + esc(t('conv_result')) + '</div><div class="res ltr" id="cvRes" aria-live="polite"></div><div class="err" id="cvErr"></div></div>';
  }
  function convRefresh() {
    var c = S.conv, r = $('#cvRes'), e = $('#cvErr'); if (!r) return;
    var v = parseNum(c.val);
    if (isNaN(v)) { r.textContent = ''; e.textContent = t('conv_err'); return; }
    e.textContent = ''; var out = convert(c.cat, c.from, c.to, v);
    out = Number(out.toPrecision(10));
    r.textContent = (Math.abs(out) !== 0 && (Math.abs(out) < 1e-6 || Math.abs(out) >= 1e15)) ? out.toExponential(4) : fmtNum(out, 6);
  }

  /* ---------- Settings ---------- */
  function seg(act, items, cur) { return '<div class="seg" role="group">' + items.map(function (i) { return '<button type="button" data-act="' + act + '" data-v="' + i[0] + '" aria-pressed="' + (cur === i[0]) + '">' + esc(i[1]) + '</button>'; }).join('') + '</div>'; }
  function pSettings() {
    return '<div class="card"><h2>' + esc(t('lang_label')) + '</h2>' + seg('set-lang', Object.keys(LANGS).map(function (k) { return [k, LANGS[k]]; }), S.lang) + '</div>' +
      '<div class="card"><h2>' + esc(t('theme_label')) + '</h2>' + seg('set-theme', [['light', t('theme_light')], ['dark', t('theme_dark')], ['system', t('theme_system')]], S.theme) + '</div>' +
      '<div class="card"><h2>' + esc(t('data_title')) + '</h2><p class="muted">' + esc(t('data_note')) + '</p>' +
      '<div class="row" style="flex-wrap:wrap"><button type="button" class="btn sec" data-act="backup-share">' + ic('share') + esc(t('backup_share')) + '</button><button type="button" class="btn sec" data-act="backup-copy">' + ic('copy') + esc(t('backup_copy')) + '</button></div>' +
      '<div class="row" style="flex-wrap:wrap;margin-top:10px"><button type="button" class="btn sec" data-act="restore">' + esc(t('restore')) + '</button><button type="button" class="btn dng" data-act="clear-all">' + ic('trash') + esc(t('clear_all')) + '</button></div></div>' +
      '<p class="muted" style="text-align:center">Simple Life · ' + esc(t('version')) + ' <span class="num">' + VERSION + '</span></p>';
  }
  function backupJSON() {
    return JSON.stringify({ app: 'SimpleLife', format: 1, exported: new Date().toISOString(), tasks: tasks, notes: notes, expenses: expenses });
  }
  function restoreDialog() {
    openSheet({
      title: t('restore'), okLabel: t('restore'),
      body: '<p class="muted">' + esc(t('restore_help')) + '</p><textarea class="field ltr" name="b" style="min-height:160px"></textarea>',
      onSubmit: function (form) {
        var o; try { o = JSON.parse(form.b.value.trim()); } catch (e) { o = null; }
        if (!o || o.app !== 'SimpleLife' || !Array.isArray(o.tasks) || !Array.isArray(o.notes) || !Array.isArray(o.expenses)) { showErr(form, t('restore_bad')); return false; }
        var nt = clean(o.tasks, cleanTask), nn = clean(o.notes, cleanNote), ne = clean(o.expenses, cleanExp), rm = findModal(form);
        confirmBox({ msg: t('restore_confirm'), okLabel: t('restore'), danger: false, onOk: function () {
          tasks = nt; notes = nn; expenses = ne;
          var ok = persist(K.tasks, tasks) && persist(K.notes, notes) && persist(K.expenses, expenses);
          if (ok) toast(t('restore_ok')); renderAll(); if (rm) destroyModal(rm);
        } });
        return false;
      }
    });
  }

  /* ---------- About ---------- */
  function contactRow(icon, label, value, act, v, actLabel) {
    return '<div class="item"><span class="row-ic">' + ic(icon) + '</span><div class="main"><div class="ttl">' + esc(label) + '</div><div class="sub ltr">' + esc(value) + '</div></div><div class="acts">' +
      iconBtn(act, icon, actLabel, 'data-v="' + esc(v) + '"') + iconBtn('copy-text', 'copy', t('copy'), 'data-v="' + esc(v) + '"') + '</div></div>';
  }
  function pAbout() {
    return '<div class="card"><div class="row" style="gap:14px"><img class="avatar" src="profile.png" alt="' + esc(t('about_name')) + '"><div class="grow"><div style="font-size:20px;font-weight:800">' + esc(t('about_name')) + '</div><div class="muted">' + esc(t('about_role')) + '</div><span class="pill">v' + VERSION + '</span></div></div>' +
      '<div class="greet" lang="ar" dir="rtl" style="text-align:center">' + esc(GREETING) + '</div><p>' + esc(t('about_intro')) + '</p>' +
      '<div class="kv"><div class="k">' + esc(t('about_location_label')) + '</div><div class="v">' + esc(t('about_location')) + '</div></div>' +
      '<div class="kv"><div class="k">' + esc(t('about_edu_label')) + '</div><div class="v">' + esc(t('about_edu')) + '</div></div>' +
      '<div class="kv"><div class="k">' + esc(t('about_purpose_label')) + '</div><div class="v">' + esc(t('about_purpose')) + '</div></div></div>' +
      '<div class="card"><h2>' + esc(t('contact')) + '</h2>' + contactRow('mail', 'Gmail', EMAIL, 'email', EMAIL, t('email_btn')) +
      PHONES.map(function (p) { return contactRow('phone', p[0], p[1], 'dial', p[1], t('call_btn')); }).join('') + '</div>' +
      '<button type="button" class="btn wide" data-act="share-app">' + ic('share') + esc(t('share_app')) + '</button>';
  }

  /* ---------- native actions ---------- */
  window.onNative = function (name, ok) {
    if (ok) return;
    toast(name === 'email' ? t('err_no_email') : name === 'dial' ? t('err_no_phone') : t('err_no_share'), true);
  };
  function nativeShare(title, text) {
    if (bridge && bridge.share) { bridge.share(title, text); return; }
    copyText(text);
  }
  function copyText(s) {
    try { if (bridge && bridge.copy) { bridge.copy(s); toast(t('toast_copied')); return; } } catch (e) {}
    function fb() {
      var a = document.createElement('textarea'); a.value = s; a.style.position = 'fixed'; a.style.opacity = '0'; document.body.appendChild(a); a.select();
      var ok = false; try { ok = document.execCommand('copy'); } catch (e) {} document.body.removeChild(a); toast(ok ? t('toast_copied') : t('err_generic'), !ok);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(s).then(function () { toast(t('toast_copied')); }, fb); else fb();
  }
  function langSheet() {
    openSheet({
      title: t('language'), dialog: true, okLabel: t('close'),
      body: '<div class="seg" style="flex-direction:column;background:none;padding:0">' + Object.keys(LANGS).map(function (k) {
        return '<button type="button" class="list-link" data-act="pick-lang" data-v="' + k + '" aria-pressed="' + (S.lang === k) + '"><span class="t">' + LANGS[k] + '</span>' + (S.lang === k ? ic('check') : '') + '</button>';
      }).join('') + '</div>',
      onSubmit: function () { return true; }
    });
  }

  /* ---------- event delegation ---------- */
  function byId(arr, id) { for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return arr[i]; return null; }
  var ACT = {
    'back': function () { back(); },
    'nav': function (d) { go(d.v); },
    'open': function (d) { go(d.v, true); },
    'reload': function () { init(); },
    'theme-toggle': function () { setTheme(effectiveTheme() === 'dark' ? 'light' : 'dark'); },
    'lang-open': langSheet,
    'pick-lang': function (d, el) { var m = findModal(el); if (m) destroyModal(m); setLang(d.v); },
    'set-lang': function (d) { setLang(d.v); },
    'set-theme': function (d) { setTheme(d.v); },
    'modal-close': function (d, el) { var m = findModal(el); if (m) requestClose(m); },
    'modal-cancel': function (d, el) { var m = findModal(el); if (m) requestClose(m); },
    'task-tab': function (d) { S.taskTab = d.v; renderMain(); },
    'task-toggle': function (d) { var x = byId(tasks, d.id); if (!x) return; x.done = !x.done; persist(K.tasks, tasks); renderMain(); },
    'task-edit': function (d) { taskEdit(d.id); },
    'task-del': function (d) { var x = byId(tasks, d.id); if (!x) return; confirmBox({ msg: t('task_delete_q'), onOk: function () { tasks = tasks.filter(function (a) { return a.id !== d.id; }); persist(K.tasks, tasks); toast(t('toast_deleted')); renderMain(); } }); },
    'note-new': function () { noteEditor(null); },
    'note-edit': function (d) { noteEditor(d.id); },
    'note-copy': function (d) { var n = byId(notes, d.id); if (n) copyText(noteText(n)); },
    'note-share': function (d) { var n = byId(notes, d.id); if (n) nativeShare(noteTitle(n), noteText(n)); },
    'note-del': function (d) { var n = byId(notes, d.id); if (!n) return; confirmBox({ msg: t('note_delete_q'), onOk: function () { notes = notes.filter(function (a) { return a.id !== d.id; }); persist(K.notes, notes); toast(t('toast_deleted')); renderMain(); } }); },
    'exp-range': function (d) { S.expRange = d.v; renderMain(); },
    'exp-new': function () { expForm(null); },
    'exp-edit': function (d) { expForm(d.id); },
    'exp-del': function (d) { var x = byId(expenses, d.id); if (!x) return; confirmBox({ msg: t('exp_delete_q'), onOk: function () { expenses = expenses.filter(function (a) { return a.id !== d.id; }); persist(K.expenses, expenses); toast(t('toast_deleted')); renderMain(); } }); },
    'calc': function (d) { calcPress(d.v); },
    'conv-swap': function () { var c = S.conv, f = c.from; c.from = c.to; c.to = f; renderMain(); },
    'backup-share': function () { nativeShare('Simple Life backup', backupJSON()); },
    'backup-copy': function () { copyText(backupJSON()); },
    'restore': restoreDialog,
    'clear-all': function () {
      confirmBox({ msg: t('clear_confirm'), okLabel: t('clear_all'), onOk: function () {
        tasks = []; notes = []; expenses = []; [K.tasks, K.notes, K.expenses].forEach(Store.del); toast(t('cleared')); renderAll();
      } });
    },
    'email': function (d) { if (bridge && bridge.email) bridge.email(d.v, 'Simple Life'); else copyText(d.v); },
    'dial': function (d) { if (bridge && bridge.dial) bridge.dial(d.v); else copyText(d.v); },
    'copy-text': function (d) { copyText(d.v); },
    'share-app': function () { nativeShare('Simple Life', 'Simple Life — ' + t('welcome_sub') + '\n' + t('about_name') + '\n' + EMAIL); }
  };
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null; if (!el) return;
    var fn = ACT[el.getAttribute('data-act')]; if (!fn) return;
    var d = {}; for (var i = 0; i < el.attributes.length; i++) { var a = el.attributes[i]; if (a.name.indexOf('data-') === 0) d[a.name.slice(5)] = a.value; }
    fn(d, el);
  });
  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.getAttribute && e.target.getAttribute('role') === 'button' && e.target.getAttribute('data-act')) { e.preventDefault(); e.target.click(); }
  });
  document.addEventListener('submit', function (e) {
    e.preventDefault();
    var form = e.target;
    if (form.id === 'taskForm') {
      var inp = $('#taskIn'), err = validateTask(inp.value), box = $('#taskErr');
      if (err) { box.textContent = err; return; }
      tasks.unshift({ id: uid(), title: inp.value.trim(), done: false, created: Date.now() });
      if (!persist(K.tasks, tasks)) { tasks.shift(); return; }
      S.taskTab = 'active'; toast(t('toast_saved')); renderMain(); var n = $('#taskIn'); if (n) n.focus(); return;
    }
    var m = findModal(form); if (!m) return;
    if (!m.o.onSubmit || m.o.onSubmit(form) === true) destroyModal(m);
  });
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el.id === 'noteQ') { S.noteQ = el.value; var l = $('#noteList'); if (l) l.innerHTML = noteListHTML(); }
    else if (el.id === 'cvVal') { S.conv.val = el.value; convRefresh(); }
    else if (el.id === 'taskIn') { var b = $('#taskErr'); if (b) b.textContent = ''; }
  });
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (el.id === 'cvCat') { var c = S.conv, k = Object.keys(UNITS[el.value]); c.cat = el.value; c.from = k[0]; c.to = k[1] || k[0]; renderMain(); }
    else if (el.id === 'cvFrom') { S.conv.from = el.value; convRefresh(); }
    else if (el.id === 'cvTo') { S.conv.to = el.value; convRefresh(); }
  });
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (S.theme === 'system') { applyTheme(); renderAll(); } });

  /* ---------- init ---------- */
  function init() {
    var l = Store.get(K.lang); S.lang = LANGS[l] ? l : 'ps';
    var th = Store.get(K.theme);
    if (th !== 'light' && th !== 'dark' && th !== 'system') { th = Store.get(K.legacyDark) === '1' ? 'dark' : 'system'; }
    S.theme = th;
    tasks = clean(loadArr(K.tasks), cleanTask); notes = clean(loadArr(K.notes), cleanNote); expenses = clean(loadArr(K.expenses), cleanExp);
    applyLang(); applyTheme(); renderAll();
  }
  window.__SL = { S: S, init: init };
  init();
})();
