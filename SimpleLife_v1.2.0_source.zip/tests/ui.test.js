/* Developer-only test: runs the bundled web UI in desktop Chromium (NOT an Android emulator).
   Usage: node tests/ui.test.js   (needs the `playwright` npm package and a Chromium browser) */
const path = require('path');
const fs = require('fs');
let chromium;
try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require(process.env.PLAYWRIGHT_PATH || '/home/claude/.npm-global/lib/node_modules/playwright')); }

const ROOT = path.resolve(__dirname, '..');
const URL = 'file://' + path.join(ROOT, 'app/src/main/assets/index.html');
const SHOTS = path.join(__dirname, 'screenshots');
fs.mkdirSync(SHOTS, { recursive: true });

const results = [];
function check(name, cond, extra) { results.push({ name, ok: !!cond, extra: cond ? '' : (extra || '') }); if (!cond) console.log('FAIL:', name, extra || ''); }

// Mock of the Android JavascriptInterface; storage is kept in localStorage under a prefix so it survives reloads.
const BRIDGE_MOCK = `
  (function(){
    var calls = (window.__calls = []);
    function k(x){ return '__native_' + x; }
    window.SimpleLifeAndroid = {
      getItem: function(key){ return localStorage.getItem(k(key)); },
      setItem: function(key, v){ localStorage.setItem(k(key), v); return true; },
      removeItem: function(key){ localStorage.removeItem(k(key)); },
      email: function(a,s){ calls.push(['email',a,s]); },
      dial: function(n){ calls.push(['dial',n]); },
      share: function(t,x){ calls.push(['share',t,x]); },
      copy: function(x){ calls.push(['copy',x]); },
      setTheme: function(d){ calls.push(['theme',d]); }
    };
  })();`;

(async () => {
  // ---- 0. i18n key parity
  const I = {}; global.window = I; require(path.join(ROOT, 'app/src/main/assets/js/i18n.js'));
  const D = I.I18N, base = Object.keys(D.en);
  ['ps', 'fa'].forEach(l => {
    const ks = Object.keys(D[l]);
    check('i18n ' + l + ' has all English keys', base.every(k => D[l][k]), base.filter(k => !D[l][k]).join(','));
    check('i18n ' + l + ' has no extra keys', ks.every(k => D.en[k]), ks.filter(k => !D.en[k]).join(','));
  });
  check('i18n no empty strings', ['ps', 'fa', 'en'].every(l => Object.values(D[l]).every(v => String(v).trim())));
  delete global.window;

  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await ctx.addInitScript(BRIDGE_MOCK);
  const requests = [];
  ctx.on('request', r => requests.push(r.url()));
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const calls = async () => page.evaluate(() => window.__calls.slice());
  const txt = async sel => (await page.textContent(sel)) || '';
  const tap = sel => page.click(sel);
  const ok = async () => { await page.waitForTimeout(40); };
  const reload = async () => { await page.reload(); await page.waitForSelector('.shell'); };

  await page.goto(URL); await page.waitForSelector('.shell');
  check('app boots and renders shell', await page.locator('.nav button').count() === 5);
  check('default language is Pashto + RTL', await page.evaluate(() => document.documentElement.lang === 'ps' && document.documentElement.dir === 'rtl'));
  check('Pashto nav label shown', (await txt('.nav')).includes('کارونه'));

  // ---- Language switching (settings) and persistence
  await tap('.nav button[data-v=more]'); await tap('[data-act=open][data-v=settings]');
  for (const [l, dir, sample] of [['en', 'ltr', 'Tasks'], ['fa', 'rtl', 'یادداشت‌ها'], ['ps', 'rtl', 'لګښتونه']]) {
    await tap('[data-act=set-lang][data-v=' + l + ']'); await ok();
    check('lang ' + l + ': dir=' + dir, await page.evaluate(d => document.documentElement.dir === d, dir));
    check('lang ' + l + ': nav translated', (await txt('.nav')).includes(sample));
    check('lang ' + l + ': settings title translated', (await txt('.top-title')).length > 2);
  }
  await tap('[data-act=set-lang][data-v=fa]'); await reload();
  check('language persists after restart (fa)', await page.evaluate(() => document.documentElement.lang === 'fa'));
  await page.evaluate(() => window.__SL.S.lang); // sanity
  // use header language sheet
  await tap('[data-act=lang-open]'); await tap('[data-act=pick-lang][data-v=en]'); await ok();
  check('header language selector switches to English', await page.evaluate(() => document.documentElement.lang === 'en' && document.documentElement.dir === 'ltr'));
  check('language dialog closes after pick', await page.locator('.scrim').count() === 0);

  // ---- Theme
  const bg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  const card = () => page.evaluate(() => { const c = document.querySelector('.card') || document.querySelector('.stat'); return getComputedStyle(c).backgroundColor; });
  await tap('.nav button[data-v=home]'); await ok();
  const bgLight = await bg();
  await tap('[data-act=theme-toggle]'); await ok();
  const bgDark = await bg();
  check('theme toggle changes theme attr', await page.evaluate(() => document.documentElement.getAttribute('data-theme')) !== null);
  check('theme toggle changes page background', bgLight !== bgDark, bgLight + ' vs ' + bgDark);
  const calls1 = await calls();
  check('native bridge told about theme', calls1.some(c => c[0] === 'theme'));
  const dkTheme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
  await reload();
  check('theme persists after restart', await page.evaluate(() => document.documentElement.getAttribute('data-theme')) === dkTheme);
  await page.screenshot({ path: SHOTS + '/home-dark-en.png' });
  // dialogs follow theme
  await tap('.nav button[data-v=tasks]'); await ok();
  await page.fill('#taskIn', 'Dark dialog task'); await tap('#taskForm button[type=submit]'); await ok();
  await tap('[data-act=task-del]'); await ok();
  const dlgBg = await page.evaluate(() => getComputedStyle(document.querySelector('.sheet')).backgroundColor);
  check('dialog uses dark surface in dark theme', dlgBg !== 'rgb(255, 255, 255)', dlgBg);
  await tap('[data-act=modal-cancel]'); await ok();
  await tap('[data-act=theme-toggle]'); await ok();
  check('theme toggles back to light', await page.evaluate(() => document.documentElement.getAttribute('data-theme')) !== dkTheme);
  // clean the task we made
  await tap('[data-act=task-del]'); await tap('.scrim .btn:not(.sec)'); await ok();

  // ---- Tasks
  await tap('.nav button[data-v=tasks]');
  check('tasks empty state shown', (await txt('#taskList')).includes('No active tasks'));
  await tap('#taskForm button[type=submit]');
  check('empty task shows validation message', (await txt('#taskErr')).includes('Please enter a task'));
  await page.fill('#taskIn', '   '); await tap('#taskForm button[type=submit]');
  check('whitespace-only task rejected', (await txt('#taskErr')).includes('Please enter'));
  await page.fill('#taskIn', 'x'.repeat(181)); await tap('#taskForm button[type=submit]');
  check('overlong task rejected', (await txt('#taskErr')).includes('too long'));
  await page.fill('#taskIn', 'Buy bread'); await tap('#taskForm button[type=submit]'); await ok();
  await page.fill('#taskIn', 'Call <b>mom</b>'); await tap('#taskForm button[type=submit]'); await ok();
  check('two tasks listed (newest first)', (await page.locator('#taskList .item').count()) === 2 && (await txt('#taskList .item')).includes('Call'));
  check('HTML in task is escaped (no injected <b>)', await page.locator('#taskList b').count() === 0);
  await tap('[data-act=task-edit] >> nth=1'); await page.fill('.sheet input[name=v]', ''); await tap('.sheet button[type=submit]');
  check('edit task: empty rejected', (await txt('.sheet .err')).includes('Please enter'));
  await page.fill('.sheet input[name=v]', 'Buy bread and milk'); await tap('.sheet button[type=submit]'); await ok();
  check('edit task saved', (await txt('#taskList')).includes('bread and milk'));
  await tap('[data-act=task-toggle] >> nth=1'); await ok();
  check('complete moves task out of active', (await page.locator('#taskList .item').count()) === 1);
  await tap('[data-act=task-tab][data-v=done]'); await ok();
  check('completed tab shows it', (await txt('#taskList')).includes('milk'));
  await reload(); await tap('.nav button[data-v=tasks]'); await tap('[data-act=task-tab][data-v=done]');
  check('tasks persist after restart', (await txt('#taskList')).includes('milk'));
  await tap('[data-act=task-toggle]'); await ok(); // back to active
  await tap('[data-act=task-tab][data-v=active]');
  await tap('[data-act=task-del] >> nth=0'); await tap('.scrim .btn.sec'); await ok();
  check('delete cancelled keeps task', (await page.locator('#taskList .item').count()) === 2);
  await tap('[data-act=task-del] >> nth=0'); await tap('.scrim .btn:not(.sec)'); await ok();
  check('delete confirmed removes task', (await page.locator('#taskList .item').count()) === 1);
  await page.screenshot({ path: SHOTS + '/tasks-en.png' });

  // ---- Notes
  await tap('.nav button[data-v=notes]');
  check('notes empty state', (await txt('#noteList')).includes('No notes yet'));
  await tap('[data-act=note-new]');
  await tap('.sheet button[type=submit]');
  check('empty note rejected with message', (await txt('.sheet .err')).includes('empty'));
  await tap('[data-act=modal-cancel]'); await ok();
  check('pristine editor closes without prompt', await page.locator('.scrim').count() === 0);
  await tap('[data-act=note-new]'); await page.fill('.sheet textarea', 'Unsaved text'); await tap('[data-act=modal-cancel]'); await ok();
  check('dirty editor asks before discarding', (await txt('.scrim.dlg')).includes('Unsaved changes'));
  await tap('.scrim.dlg .btn.sec'); await ok(); // keep editing
  check('keep editing keeps the editor and text', (await page.inputValue('.sheet textarea')) === 'Unsaved text');
  // back button with dirty editor
  const handled = await page.evaluate(() => window.handleBack()); await ok();
  check('system back with dirty editor shows prompt', handled === true && (await page.locator('.scrim.dlg').count()) === 1);
  await tap('.scrim.dlg .btn:not(.sec)'); await ok();
  check('discard closes editor, nothing saved', await page.locator('.scrim').count() === 0 && (await txt('#noteList')).includes('No notes yet'));
  await tap('[data-act=note-new]'); await page.fill('.sheet input[name=title]', 'Shopping'); await page.fill('.sheet textarea', 'eggs\nrice\nsugar'); await tap('.sheet button[type=submit]'); await ok();
  await tap('[data-act=note-new]'); await page.fill('.sheet textarea', 'Meeting at 5'); await tap('.sheet button[type=submit]'); await ok();
  check('two notes saved', (await page.locator('#noteList .item').count()) === 2);
  await page.fill('#noteQ', 'rice'); await ok();
  check('search filters notes', (await page.locator('#noteList .item').count()) === 1 && (await txt('#noteList')).includes('Shopping'));
  check('search keeps focus/typing (input not re-rendered)', await page.evaluate(() => document.activeElement && document.activeElement.id === 'noteQ'));
  await page.fill('#noteQ', 'zzz'); await ok();
  check('search no-match message', (await txt('#noteList')).includes('No matching'));
  await page.fill('#noteQ', ''); await ok();
  await page.fill('#noteQ', 'shopping'); await ok();
  await tap('[data-act=note-copy]'); await tap('[data-act=note-share]'); await ok();
  const c2 = await calls();
  check('copy note calls native clipboard with full text', c2.some(c => c[0] === 'copy' && c[1] === 'Shopping\n\neggs\nrice\nsugar'));
  check('share note calls native share sheet', c2.some(c => c[0] === 'share' && c[1] === 'Shopping' && c[2].includes('sugar')));
  await tap('#noteList [data-act=note-edit] >> nth=0'); await ok();
  await page.fill('.sheet textarea', 'eggs\nrice\nsugar\ntea'); await tap('.sheet button[type=submit]'); await ok();
  await reload(); await tap('.nav button[data-v=notes]');
  check('edited note persists after restart', (await txt('#noteList')).includes('Shopping'));
  await tap('[data-act=note-del] >> nth=0'); await ok();
  check('note delete asks confirmation', (await txt('.scrim.dlg')).includes('permanently'));
  await tap('.scrim.dlg .btn:not(.sec)'); await ok();
  check('note deleted after confirm', (await page.locator('#noteList .item').count()) === 1);
  await page.screenshot({ path: SHOTS + '/notes-en.png' });

  // ---- Expenses
  await tap('.nav button[data-v=expenses]');
  check('expenses empty state', (await txt('main')).includes('No expenses'));
  const addExp = async (title, amount, cat, date) => {
    await tap('[data-act=exp-new]');
    await page.fill('.sheet input[name=title]', title); await page.fill('.sheet input[name=amount]', amount);
    if (cat) await page.selectOption('.sheet select[name=cat]', cat);
    if (date) await page.fill('.sheet input[name=date]', date);
    await tap('.sheet button[type=submit]'); await ok();
  };
  await tap('[data-act=exp-new]'); await tap('.sheet button[type=submit]');
  check('expense: empty title rejected', (await txt('.sheet .err')).includes('Enter a title'));
  await page.fill('.sheet input[name=title]', 'Bread');
  for (const bad of ['', 'abc', '0', '-5', '1.234', '12e3', '1..2']) {
    await page.fill('.sheet input[name=amount]', bad); await tap('.sheet button[type=submit]');
    check('expense: invalid amount "' + bad + '" rejected', (await txt('.sheet .err')).includes('valid amount') && await page.locator('.scrim').count() === 1);
  }
  await page.fill('.sheet input[name=amount]', '10'); await page.fill('.sheet input[name=date]', ''); await tap('.sheet button[type=submit]');
  check('expense: missing date rejected', (await txt('.sheet .err')).includes('valid date'));
  await tap('[data-act=modal-cancel]'); await ok();
  await addExp('Bread', '0.10', 'food');
  await addExp('Tea', '0.20', 'food');
  check('totals use exact arithmetic (0.10+0.20 = 0.30)', (await txt('.big')).replace(/\s+/g, ' ').trim() === '0.3 AFN', await txt('.big'));
  await addExp('Taxi', '1,250.50', 'transport');
  await addExp('Persian digits', '۱۵۰', 'bills');
  check('thousands separator and Persian digits accepted; total correct', (await txt('.big')).includes('1,400.8'), await txt('.big'));
  check('category breakdown shown', (await page.locator('.cat-row').count()) === 3);
  await addExp('Old rent', '5000', 'bills', '2020-01-15');
  check('month view excludes old expense', !(await txt('main')).includes('Old rent'));
  await tap('[data-act=exp-range][data-v=all]'); await ok();
  check('all-time view includes old expense and total', (await txt('main')).includes('Old rent') && (await txt('.big')).includes('6,400.8'), await txt('.big'));
  await tap('[data-act=exp-edit] >> nth=-1'); await ok();
  await page.fill('.sheet input[name=amount]', '4000'); await tap('.sheet button[type=submit]'); await ok();
  check('edit expense updates total', (await txt('.big')).includes('5,400.8'), await txt('.big'));
  await reload(); await tap('.nav button[data-v=expenses]'); await tap('[data-act=exp-range][data-v=all]');
  check('expenses persist after restart', (await txt('.big')).includes('5,400.8') && (await txt('main')).includes('Taxi'));
  await tap('[data-act=exp-del] >> nth=-1'); await tap('.scrim .btn:not(.sec)'); await ok();
  check('delete expense updates total', !(await txt('main')).includes('Old rent') && (await txt('.big')).includes('1,400.8'));
  await tap('[data-act=exp-range][data-v=month]');
  await page.screenshot({ path: SHOTS + '/expenses-en.png', fullPage: false });

  // ---- Calculator
  await tap('.nav button[data-v=more]'); await tap('[data-act=open][data-v=calc]');
  const press = async s => { for (const ch of s) await page.click('.key[data-v="' + ch + '"]'); };
  const res = async () => (await txt('#cRs')).trim();
  await press('2+3×4='); check('calc: 2+3×4 = 14 (precedence)', (await res()) === '14', await res());
  await tap('.key[data-v=C]'); await press('0.1+0.2='); check('calc: 0.1+0.2 = 0.3', (await res()) === '0.3', await res());
  await tap('.key[data-v=C]'); await press('5÷0='); check('calc: divide by zero error', (await res()).includes('Cannot divide'), await res());
  await press('7'); check('calc: input after error starts fresh', (await txt('#cEx')).trim() === '7');
  await tap('.key[data-v=C]'); await press('50%'); await press('+10='); check('calc: percent 50%+10 = 10.5', (await res()) === '10.5', await res());
  await tap('.key[data-v=C]'); await press('12'); await tap('.key[data-v=B]'); check('calc: backspace', (await txt('#cEx')).trim() === '1');
  await tap('.key[data-v=C]'); await press('1.5.5'); check('calc: second decimal point ignored', (await txt('#cEx')).trim() === '1.55' || (await txt('#cEx')).trim() === '1.5' + '5');
  await tap('.key[data-v=C]'); await press('9−'); await press('×'); await press('2='); check('calc: operator replacement 9−→× = 18', (await res()) === '18', await res());
  await tap('.key[data-v=C]'); await press('3−8='); check('calc: negative result', (await res()) === '-5', await res());
  await press('+10='); check('calc: continue from result', (await res()) === '5', await res());
  await tap('.key[data-v=C]'); await press('1000×1000='); check('calc: grouping 1,000,000', (await res()) === '1,000,000', await res());
  await page.screenshot({ path: SHOTS + '/calc-en.png' });

  // ---- Converter
  await tap('[data-act=back]'); await tap('[data-act=open][data-v=conv]');
  await page.selectOption('#cvFrom', 'km'); await page.selectOption('#cvTo', 'm'); await page.fill('#cvVal', '1.5'); await ok();
  check('convert 1.5 km → 1,500 m', (await txt('#cvRes')).trim() === '1,500', await txt('#cvRes'));
  await tap('[data-act=conv-swap]'); await ok();
  check('swap works (1.5 m → 0.0015 km)', (await txt('#cvRes')).trim() === '0.0015', await txt('#cvRes'));
  await page.fill('#cvVal', 'abc'); await ok();
  check('converter: invalid number message', (await txt('#cvErr')).includes('valid number') && (await txt('#cvRes')).trim() === '');
  await page.selectOption('#cvCat', 'temp'); await page.selectOption('#cvFrom', 'c'); await page.selectOption('#cvTo', 'f'); await page.fill('#cvVal', '100'); await ok();
  check('convert 100 °C → 212 °F', (await txt('#cvRes')).trim() === '212', await txt('#cvRes'));
  await page.fill('#cvVal', '-40'); await ok(); check('-40 °C = -40 °F', (await txt('#cvRes')).trim() === '-40');
  await page.fill('#cvVal', '0'); await page.selectOption('#cvTo', 'k'); await ok(); check('0 °C = 273.15 K', (await txt('#cvRes')).trim() === '273.15', await txt('#cvRes'));
  await page.selectOption('#cvCat', 'weight'); await page.selectOption('#cvFrom', 'kg'); await page.selectOption('#cvTo', 'lb'); await page.fill('#cvVal', '1'); await ok();
  check('1 kg → 2.204623 lb', (await txt('#cvRes')).trim() === '2.204623', await txt('#cvRes'));

  // ---- About / actions
  await page.evaluate(() => window.handleBack()); await page.evaluate(() => window.handleBack()); await ok();
  await tap('.nav button[data-v=more]'); await tap('[data-act=open][data-v=about]');
  const aboutTxt = await txt('main');
  check('about shows required identity', aboutTxt.includes('Abdul Samim Niazai') && aboutTxt.includes('Alingar') && aboutTxt.includes('Uruzgan University'));
  check('about keeps Pashto greeting verbatim', aboutTxt.includes('وَعَلَيْكُم السَّلَام وَرَحْمَةُ اَللهِ وَبَرَكاتُهُ'));
  check('about lists all four contact items', ['samimpatan8@gmail.com', '0789591758', '0767803096', '0747320602'].every(s => aboutTxt.includes(s)));
  let imgOk = true; try { await page.waitForFunction(() => { const i = document.querySelector('.avatar'); return i && i.complete && i.naturalWidth > 0; }, null, { timeout: 5000 }); } catch (e) { imgOk = false; }
  check('profile photo loads', imgOk);
  await tap('[data-act=email]'); await tap('[data-act=dial] >> nth=0'); await tap('[data-act=dial] >> nth=2'); await ok();
  const c3 = await calls();
  check('email action → bridge.email(address)', c3.some(c => c[0] === 'email' && c[1] === 'samimpatan8@gmail.com'));
  check('call action → bridge.dial (dialer only)', c3.some(c => c[0] === 'dial' && c[1] === '0789591758') && c3.some(c => c[0] === 'dial' && c[1] === '0747320602'));
  await page.evaluate(() => window.onNative('email', false)); await ok();
  check('missing email app → localized error toast', (await txt('#toast')).includes('No email app'));
  await page.evaluate(() => window.onNative('dial', false)); await ok();
  check('missing phone app → localized error toast', (await txt('#toast')).includes('No phone app'));
  await tap('[data-act=copy-text] >> nth=0'); await ok();
  check('copy contact uses native clipboard', (await calls()).some(c => c[0] === 'copy' && c[1] === 'samimpatan8@gmail.com'));
  for (const l of ['ps', 'fa', 'en']) {
    await page.evaluate(x => { localStorage.setItem('__native_sl_lang', x); }, l); await reload();
    await tap('.nav button[data-v=more]'); await tap('[data-act=open][data-v=about]'); await ok();
    check('about renders in ' + l + ' without overflow', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    await page.screenshot({ path: SHOTS + '/about-' + l + '.png' });
  }

  // ---- Backup / restore / clear
  await page.evaluate(() => { localStorage.setItem('__native_sl_lang', 'en'); }); await reload();
  await tap('.nav button[data-v=more]'); await tap('[data-act=open][data-v=settings]');
  await tap('[data-act=backup-copy]'); await ok();
  const bk = (await calls()).filter(c => c[0] === 'copy').pop()[1];
  const parsed = JSON.parse(bk);
  check('backup JSON has app marker + data arrays', parsed.app === 'SimpleLife' && parsed.tasks.length === 1 && parsed.notes.length === 1 && parsed.expenses.length >= 3, bk.slice(0, 120));
  await tap('[data-act=clear-all]'); await tap('.scrim .btn.sec'); await ok();
  check('clear-all cancel keeps data', await page.evaluate(() => JSON.parse(localStorage.getItem('__native_sl_tasks')).length === 1));
  await tap('[data-act=clear-all]'); await tap('.scrim .btn:not(.sec)'); await ok();
  check('clear-all wipes data', await page.evaluate(() => localStorage.getItem('__native_sl_tasks') === null && localStorage.getItem('__native_sl_notes') === null));
  await tap('[data-act=restore]'); await page.fill('.sheet textarea', 'not json'); await tap('.sheet button[type=submit]');
  check('restore rejects invalid text', (await txt('.sheet .err')).includes('not valid'));
  await page.fill('.sheet textarea', bk); await tap('.sheet button[type=submit]'); await ok();
  await tap('.scrim.dlg .btn:not(.sec)'); await ok();
  check('restore re-creates data and closes dialogs', await page.locator('.scrim').count() === 0 && await page.evaluate(() => JSON.parse(localStorage.getItem('__native_sl_notes')).length === 1));
  await page.fill; // no-op
  // hostile restore payload is sanitised
  await tap('[data-act=restore]');
  await page.fill('.sheet textarea', JSON.stringify({ app: 'SimpleLife', tasks: [{ title: '<img src=x onerror=alert(1)>', done: 'yes' }, null, 5], notes: [], expenses: [{ title: 'bad', amount: -3 }, { title: 'ok', amount: '12.5', category: 'hack', date: 'zzz' }] }));
  await tap('.sheet button[type=submit]'); await tap('.scrim.dlg .btn:not(.sec)'); await ok();
  const sane = await page.evaluate(() => ({ t: JSON.parse(localStorage.getItem('__native_sl_tasks')), e: JSON.parse(localStorage.getItem('__native_sl_expenses')) }));
  check('restore sanitises types/ranges/categories', sane.t.length === 1 && sane.t[0].done === false && sane.e.length === 1 && sane.e[0].category === 'general' && /^\d{4}-\d{2}-\d{2}$/.test(sane.e[0].date), JSON.stringify(sane));

  // ---- Back navigation
  await page.evaluate(() => { document.querySelector('.nav button[data-v=home]').click(); });
  check('back on Home is not handled (app may exit)', (await page.evaluate(() => window.handleBack())) === false);
  await tap('[data-act=open][data-v=calc]');
  check('back from Home→Calc returns to Home', (await page.evaluate(() => window.handleBack())) === true && (await txt('.top-title')) === 'Simple Life');
  await tap('.nav button[data-v=notes]'); await tap('[data-act=note-new]');
  check('back closes open editor first', (await page.evaluate(() => window.handleBack())) === true && await page.locator('.scrim').count() === 0 && (await txt('.top-title')) === 'Notes');

  // ---- Legacy data migration (old app stored plain localStorage keys with different shapes)
  const legacy = await ctx.newPage();
  await legacy.addInitScript(() => {
    localStorage.clear();
    localStorage.setItem('sl_tasks', JSON.stringify([{ title: 'Old task', done: true }]));
    localStorage.setItem('sl_notes', JSON.stringify([{ text: 'Old note', date: '10/28/2026, 1:00:00 PM' }]));
    localStorage.setItem('sl_expenses', JSON.stringify([{ title: 'Old exp', amount: 25, category: 'Food', date: '2026-10-01' }]));
    localStorage.setItem('sl_dark', '1');
  });
  const lerr = []; legacy.on('pageerror', e => lerr.push(e.message));
  await legacy.goto(URL); await legacy.waitForSelector('.shell');
  const lres = await legacy.evaluate(() => ({ th: document.documentElement.getAttribute('data-theme'), body: document.body.innerText }));
  check('legacy dark flag migrated to dark theme', lres.th === 'dark');
  await legacy.click('.nav button[data-v=notes]');
  check('legacy note visible after upgrade', (await legacy.textContent('#noteList')).includes('Old note'));
  await legacy.click('.nav button[data-v=expenses]'); await legacy.click('[data-act=exp-range][data-v=all]');
  check('legacy expense (capitalised Food mapped to localized category) visible', (await legacy.textContent('main')).includes('Old exp') && (await legacy.textContent('main')).includes('خواړه'));
  check('legacy page: no JS errors', lerr.length === 0, lerr.join('|'));
  await legacy.close();

  // ---- Fallback without native bridge (plain browser): localStorage storage works
  const plain = await browser.newContext({ viewport: { width: 390, height: 780 } });
  const pp = await plain.newPage(); const perr = []; pp.on('pageerror', e => perr.push(e.message));
  await pp.goto(URL); await pp.waitForSelector('.shell');
  await pp.click('.nav button[data-v=tasks]'); await pp.fill('#taskIn', 'No bridge task'); await pp.click('#taskForm button[type=submit]');
  await pp.reload(); await pp.waitForSelector('.shell'); await pp.click('.nav button[data-v=tasks]');
  check('without native bridge: localStorage fallback persists data', (await pp.textContent('#taskList')).includes('No bridge task'));
  await pp.click('.nav button[data-v=more]'); await pp.click('[data-act=open][data-v=about]'); await pp.click('[data-act=email]');
  check('without bridge: email button copies instead of crashing', perr.length === 0, perr.join('|'));
  await plain.close();

  // ---- Offline: nothing but file:// was requested
  const nonFile = requests.filter(u => !u.startsWith('file://'));
  check('no network requests were made (all requests are file://)', nonFile.length === 0, nonFile.join(','));
  check('no JS errors / console errors during whole run', errors.length === 0, errors.join(' | '));

  // ---- Layout checks at several sizes and languages (no horizontal overflow, nav labels not clipped)
  for (const [w, h] of [[320, 640], [360, 740], [412, 915], [768, 1024]]) {
    for (const l of ['ps', 'fa', 'en']) {
      await page.setViewportSize({ width: w, height: h });
      await page.evaluate(x => { localStorage.setItem('__native_sl_lang', x); }, l); await reload();
      for (const pg of ['home', 'tasks', 'notes', 'expenses', 'more']) {
        await page.click('.nav button[data-v=' + pg + ']');
        const ov = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
        check('no horizontal overflow ' + w + 'px ' + l + ' ' + pg, ov <= 1, 'overflow ' + ov);
      }
      const clipped = await page.evaluate(() => [...document.querySelectorAll('.nav button span')].filter(s => s.scrollWidth > s.parentElement.clientWidth + 1).length);
      check('nav labels fit ' + w + 'px ' + l, clipped === 0, clipped + ' clipped');
    }
  }
  await page.setViewportSize({ width: 390, height: 780 });
  for (const l of ['ps', 'fa']) { await page.evaluate(x => localStorage.setItem('__native_sl_lang', x), l); await reload(); await page.screenshot({ path: SHOTS + '/home-' + l + '.png' }); await page.click('.nav button[data-v=tasks]'); await page.screenshot({ path: SHOTS + '/tasks-' + l + '.png' }); }

  await browser.close();
  const pass = results.filter(r => r.ok).length, fail = results.filter(r => !r.ok);
  fs.writeFileSync(path.join(__dirname, 'last-results.json'), JSON.stringify({ total: results.length, passed: pass, failed: fail }, null, 2));
  console.log('\nRESULT: ' + pass + '/' + results.length + ' passed');
  fail.forEach(f => console.log(' - FAILED:', f.name, f.extra));
  process.exit(fail.length ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
